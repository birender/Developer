/* 
 * Created By : Birender Singh Rana
 * Date		  : 29 June 2015	
 */

var app = angular.module('business', ['ngRoute','720kb.datepicker']);

app.config(function ($routeProvider, $locationProvider) {
	$routeProvider
			.when('/', {
				templateUrl: 'pages/index.html',
				controller: 'mainController'
			})
			.when('/about', {
				templateUrl: 'pages/about.php',
				controller: 'aboutController'
			})
			.when('/services', {
				templateUrl: 'pages/services.html',
				controller: 'servicesController'
			})
			.when('/solutions', {
				templateUrl: 'pages/solutions.html',
				controller: 'solutionsController'
			})
			.when('/contact', {
				templateUrl: 'pages/contact.php',
				controller: 'contactController'
			});
});

app.controller('mainController', function ($scope, $location) {
	$scope.status = 1;

});

app.controller('aboutController', function ($scope, $http) {
	$scope.status = 2;
	$http.post('http://localhost/Angular/pages/ndate.php', {cache: true}).success(function (data) {
		$scope.updatedTime = data;
	});
});

app.controller('servicesController', function ($scope) {
	$scope.status = 3;
});

app.controller('solutionsController', function ($scope) {
	$scope.status = 4;
});

app.controller('contactController', function ($scope) {
	$scope.status = 5;
});

app.controller('PanelController', function ($scope) {
	var url = window.location.pathname;
	var filename = url.substring(url.lastIndexOf('/') + 1);

	this.selectTab = function (setTab, $scope) {
		this.tab = setTab;
	};

	this.isSelected = function (checkTab) {
		this.tab = checkTab;
	}

});

app.directive('headerSection', function () {
	return {
		restrict: 'E',
		templateUrl: 'common/header-section.html'
	};
});

app.directive('footerSection', function () {
	return {
		restrict: 'E',
		templateUrl: 'common/footer-section.html'
	};
});